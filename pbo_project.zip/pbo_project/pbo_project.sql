-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 21 Sep 2023 pada 07.25
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pbo_project`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesanan`
--

CREATE TABLE `pesanan` (
  `id_user` varchar(11) NOT NULL,
  `tanggal` varchar(20) NOT NULL,
  `jenis` varchar(20) NOT NULL,
  `supir` varchar(11) NOT NULL,
  `masa` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pesanan`
--

INSERT INTO `pesanan` (`id_user`, `tanggal`, `jenis`, `supir`, `masa`, `total`) VALUES
('ANAS', 'Sep 7, 2023', 'MOBIL (JELATA)', 'PAKET 2', 2, 675000),
('ANAS', 'Sep 7, 2023', 'MOBIL (JELATA)', 'PAKET 2', 1, 375000),
('AMELIA', 'Sep 8, 2023', 'MOBIL (JELATA)', 'PAKET 1', 2, 650000),
('ANAS', 'Sep 8, 2023', 'MOBIL (JELATA)', 'PAKET 1', 1, 350000),
('ANAS', 'Sep 7, 2023', 'MOBIL (KING)', 'PAKET 1', 2, 1050000),
('AMELIA', 'Sep 1, 2023', 'MOBIL (KING)', 'PAKET 1', 2, 1050000),
('ANAS', 'Sep 8, 2023', 'MOBIL (JELATA)', 'PAKET 1', 1, 350000),
('ANAS', 'Sep 1, 2023', 'MOBIL (JELATA)', 'PAKET 1', 2, 650000),
('ANAS', 'Sep 14, 2023', 'MOBIL (KING)', 'PAKET 2', 2, 1075000),
('SAFIRA', 'Sep 7, 2023', 'MOTOR', 'PAKET 2', 2, 575000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` varchar(20) NOT NULL,
  `id_password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `id_password`) VALUES
('', ''),
('AMELIA', 'AMELIA'),
('ANAS', 'ANAS'),
('cimul', 'cimul'),
('SAFIRA', 'SAFIRA');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  ADD CONSTRAINT `pesanan_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
